#군집화

# 내가 해야할 일!
# 1.data를 읽어오고
# 2.data 별 타입 정의 하고
# 3.scale 함.
# 4.kmeans를 돌림.

getwd()

data <-read.csv('finaltest.csv')
# 전부다 비율! 그대로 사용해도 됨!
dim(data)[1]
#
library('ggplot2')





str(data)

temp<- scale(data[,-c(1)])

cluster <- kmeans(temp,3)
cluster$betweenss


install.packages("NbClust")
library(NbClust)
nc <- NbClust(temp, min.nc = 2, max.nc = 15, method="kmeans")
par(mfrow=c(1,1))
barplot(table(nc$Best.n[1,]),
        xlab="Numer of Clusters", ylab="Number of Criteria",
        main="Number of Clusters Chosen")
cluster$cluster
