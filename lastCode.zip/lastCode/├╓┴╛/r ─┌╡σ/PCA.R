getwd()
sum<-read.csv('final.csv')
str(tired)
#247개의 컬럼
View(tired)
View(as.data.frame(colnames(tired)))
tired$late_wi
#late 합치기
i<-1
j<-1
length(tired$No)
tmp<-list()
for(i in 1:length(tired$No)){
  tmp[[i]]<-tired$No[i]
  for(j in 1:49){
    #구간이 주어지고 그 구간 안에서 -1이 아닌 값들의 합을 뽑자
  }
}
class(tired)
class(name)
#late 
iris
str(iris)
library(dplyr)
test<-iris%>%select(c(1:3))
#%>%apply(1,filter(>5))
View(apply(test,1,sum))
#late 3~51
#over 52~100
#hol 101~ 149
#break 150~198
#off 248~ 287
#half 297~345
#regon 346~394
#regoff 395~443
#worktime 444~541
#restday 542~590
test<-tired[,which(c(3:51)!= -1)]
View(test)

#sum 읽어오기
#finaltest.csv 읽어오기
sum<-read.csv('finaltest.csv')

sum <-read.csv('sum.csv')
str(sum)
colnames(sum)
sum <- sum[,-c(8)]
sum <- sum[,-c(11)]
sum <- sum[,c(1,12,13,14,15,16,17,18)]
sum$dhol<-as.integer(sum$dhol)
View(sum)
sum <- sum[,c(1,3,4,5,6,7,10)]

#표준화

#1 2: half 총합 3: half나눔 
train<-scale(sum)
train2<-scale(sum)
train3<-scale(sum)
train4<-scale(sum[,-c(1,2,10)])
str(train)
View(train)
View(train4)
cor(train)
cor(sum)
train<-train[,-c(1)]
train2<-train2[,-c(1)]
train3<-train3[,-c(1)]
View(cor(train[,-c(1)]))
View(cor(train))
View(cor(train2))
# 주성분 분석! 

tr.pca<-prcomp(train,center = T,scale. = T)
print(tr.pca)

View(as.data.frame(print(tr.pca$rotation)))
plot(tr.pca,type='l')


summary(tr.pca)

# 주성분 분석2!

tr2.pca<-prcomp(train2,center = T,scale. = T)
print(tr2.pca)

View(as.data.frame(print(tr2.pca$rotation)))
plot(tr2.pca,type='l')


summary(tr2.pca)

#주성분 분석 3!

tr3.pca <- prcomp(train3,center = T,scale. = T)
print(tr3.pca)
eigen(tr3.pca$rotation)

View(as.data.frame(tr3.pca$rotation))

tr4.pca <- prcomp(train4,center = T,scale. = T)
View(cor(train4))
View(as.data.frame(tr4.pca$rotation))

# factor
R<-cor(train2)
tr.facl<-factanal(covmat=R,factors=3,rotation = "varimax")
tr.facl<-factanal(covmat=R,factors=2,rotation = "none")
tr.facl

##########

biplot(prcomp(train2), cex = c(0.7, 0.8))

# 관측치별 주성분1, 주성분2 점수 계산(PC1 score, PC2 score)
pc1 <- predict(tr.pca)[,1]
pc2 <- predict(tr.pca)[,2]

library(ggplot2)

library("devtools")
install_github("kassambara/factoextra")
library("factoextra")
fviz_pca_biplot(tr3.pca)

plot(tr3.pca,choix="var")
## PCA 그림으로 나타내기 
fviz_pca_var(tr2.pca,col.var="contrib")+scale_color_gradient2(low="white", mid="blue", 
                                                              high="red", midpoint=10)+theme_bw()

fviz_pca_var(tr3.pca,col.var="contrib")+scale_color_gradient2(low="white", mid="blue", 
                                                              high="red", midpoint=10)+theme_bw()


# 정리를 해보자 ! 컬러믈 선택해야되는데 
# 지각 ~ 오전 반차의 영향! 근데 오전 반차가 더 커야함 . 
# 그리고 상관관계 고려해야함

colnames(sum)

# barplot

tr2.pca$rotation[,1]
barplot(tr2.pca$rotation[,1],col=rainbow(6),ylim = c(-0.6,0.4), las = 2, main = "PC1")
tmp<-list()
tmp<-sum(-tr2.pca$rotation[,1]*train2[1,])
i<-2
for(i in 2:dim(train2)[1]){
  tmp<-rbind(tmp,sum(-tr2.pca$rotation[,1]*train2[i,]))
}
length(tmp)
test<-as.data.frame(cbind(sum$No,tmp))
View(test)
plot(test)
str(test)
ggplot(data=test, aes(x=V1,y=V2))+geom_point(shape=15, size=3, colour="red")
plot(x=test$V1,y=test$V2)
plot(sum$dover~sum$No)

#kmeans

getwd()

data <-read.csv('finaltest.csv')
# 전부다 비율! 그대로 사용해도 됨!
dim(data)[1]
#
library('ggplot2')

str(data)

temp<- scale(data[,-c(1)])

cluster <- kmeans(temp,3)
cluster$betweenss


install.packages("NbClust")
library(NbClust)
nc <- NbClust(temp, min.nc = 2, max.nc = 15, method="kmeans")
par(mfrow=c(1,1))
barplot(table(nc$Best.n[1,]),
        xlab="Numer of Clusters", ylab="Number of Criteria",
        main="Number of Clusters Chosen")
cluster$cluster


## iris test
install.packages('ggfortify')
library(ggfortify)
#df <- iris[c(1, 2, 3, 4)]
#autoplot(prcomp(df))
#autoplot(prcomp(df), data = iris, colour = 'Species')
#autoplot(tr2.pca,colour=cluster$cluster)

#kmeans 그림그리기! 흠 이거 안됨 ㅠㅠ!
g<-ggplot(tr2.pca,aes(x=PC1,y=PC2))
g+geom_point(tr2.pca$x,aes(color=cluster$cluster),size=4)+scale_colour_gradientn(colours = c("#CC6666", "#9999CC", "#66CC99"))
tr2.pca$sdev
tr2.pca$center
tr2.pca$scale
tr2.pca$x
tr2.pca$rotation
g<-g+geom_point(aes(color=cluster$cluster),size=4)+scale_colour_gradientn(colours = c("#CC6666", "#9999CC", "#66CC99"))


#+scale_fill_manual(values=c("#CC6666", "#9999CC", "#66CC99"))
