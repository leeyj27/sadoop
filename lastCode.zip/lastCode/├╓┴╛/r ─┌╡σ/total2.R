###위치지정
#setwd("E:/빅데이터 청년인재/Final_Project/R")
getwd()

###사용한 라이브러리
library(dplyr)

###파일 불러오기
last<-read.csv("last.csv")
attend<-read.csv("attendance.csv")
late<-read.csv("flate.csv")
foff<-read.csv("foff.csv")
over<-read.csv("fover.csv")
work<-read.csv("fworkend.csv")


###사용자지정함수정의
keymaker<-function(dataset){
  dataset%>%mutate(key=paste(No,date))%>%select(-c(No,date))
}
L <- function(data){
  length(unique(data$No))
}

###new alldaysform
#최초, 최후 날짜 구하기
minmax <- last%>%
  mutate(date=as.Date(date))%>%
  group_by(No)%>%
  summarise(min_date = min(date), max_date = max(date))%>%
  mutate(diff_date = max_date-min_date+1)%>%
  select(No,min_date,max_date,diff_date)

alldays<-c()
for(i in 1:length(minmax$No)){
  myId<-rep(minmax$No[i], times = minmax$diff_date[i])
  Days<-rep(minmax$min_date[i]:minmax$max_date[i], 1)
  me<-cbind(myId, Days)
  alldays<-rbind(alldays, me)
}

#생성된alldays의 칼럼명 바꾸기
alldays<-as.data.frame(alldays)%>%select(No=myId,date=Days)

#마지막으로 알아보기 힘든 꼴로 출력되는 date변수의 모양을 바꿔주면 끝!
alldays$date<-as.Date(alldays$date,"1970-01-01")

###attendNONA생성
attendNoNA <- attend%>%
  filter(!(is.na(On)&is.na(Off_time)==TRUE))%>%
  select(No,date=Date,On,On_time,Off_time)

###key생성
kform<-keymaker(alldays%>%mutate(wday=as.POSIXlt(date)$wday)%>%select(No,date,wday))
kwork<-keymaker(work)
klate<-keymaker(late)
kover<-keymaker(over)
koff<-keymaker(foff)
kattend<-keymaker(attendNoNA%>%select(No,date=date,On,On_time,Off_time))
#merge
merged<-merge(kform,kwork,by='key',all=TRUE)
merged<-merge(merged,klate,by='key',all=TRUE)
merged<-merge(merged,koff,by='key',all=TRUE)
merged<-merge(merged,kover,by='key',all=TRUE)
merged<-merge(merged,kattend,by='key',all.x=TRUE)
#key분리
merged <- transform(merged, No = substr(key, 1, 7))
merged <- transform(merged, date = substr(key, 9, 18))

#holiday(weekend & holiday==1, not==0)
#신정
firstd<-as.POSIXct("2015-01-01")		
#설연휴	
newyeard_s<-as.POSIXct("2015-02-18")
newyeard_f<-as.POSIXct("2015-02-20")	
#삼일절
mansed<-as.POSIXct("2015-03-01")		
#어린이날
childd<-as.POSIXct("2015-05-05")		
#석탄일
budad<-as.POSIXct("2015-05-25")		
#현충일
memoriald<-as.POSIXct("2015-06-06")		
#광복절
liberad<-as.POSIXct("2015-08-15")		
#추석
thgivind_s<-as.POSIXct("2015-09-26")
thgivind_f<-as.POSIXct("2015-09-29") #	29일 대체공휴일
#개천절
foundd<-as.POSIXct("2015-10-03")		
#한글날
koreand<-as.POSIXct("2015-10-09")		
#크리스마스
christd<-as.Date("2015-12-25")	

holid<-merged%>%
  mutate(date=as.POSIXct(date))%>%
  filter(((date==firstd|date==mansed|date==childd|date==budad
           |date==memoriald|date==liberad|date==foundd|date==koreand|date==christd))
| (date>=newyeard_s)&(date<=newyeard_f)
| (date>=thgivind_s)&(date<=thgivind_f)
| (wday==6|wday==0))%>%
  mutate(holiday=1)%>%select(key,holiday)
merged<-merge(merged,holid,by='key',all=TRUE)
View(holid)
#work(worked==1, not==0)
keylast<-keymaker(last)
keylast<-transform(keylast, hour = substr(time, 1, 2))
workd<-keylast%>%filter(as.numeric(hour)>=6)%>%group_by(key)%>%summarise(work=1)
merged<-merge(merged,workd,by='key',all=TRUE)

#not_in_att(not in attendance.csv)
x<-unique(merged$No)
y<-unique(attendNoNA$No)
missinpp<-x[is.na(match(x,y))]

notin<-merged%>%
  filter(No=="4017990"|No=="4020020"|No=="4024024"|No=="4024160"
         |No=="4026004"|No=="4026104"|No=="4028110"|No=="4028160"
         |No=="4030108"|No=="4030116")%>%
  mutate(missinatt=1)%>%select(key,missinatt)
merged<-merge(merged,notin,by='key',all=TRUE)


###filtering시작!
##Day
#half_am
halfam1<-merged%>%
  filter((!missinatt==1)&(on_hour>=15)|(On=="반차"&!Off_time=="반차"))%>%
  filter(is.na(holiday)|work==1)%>%
  mutate(half_am=1)%>%select(key,half_am)

halfam2<-merged%>%
  filter(missinatt==1&on_hour>=15)%>%
  filter(is.na(holiday)&work==1)%>%
  mutate(half_am=1)%>%select(key,half_am)

halfam<-rbind(halfam1,halfam2)
merged<-merge(merged,halfam,by='key',all=TRUE)

#half_pm
halfpm1<-merged%>%
  filter((Off_time=="반차"&!On=="반차")&off_hour<=16)%>%
  filter(is.na(holiday)&work==1)%>%
  mutate(half_pm=1)%>%select(key,half_pm)

halfpm2<-merged%>%
  filter((off_hour<=16)&(missinatt==1))%>%
  filter(is.na(holiday)&work==1)%>%
  mutate(half_pm=1)%>%select(key,half_pm)

halfpm<-rbind(halfpm1,halfpm2)
merged<-merge(merged,halfpm,by='key',all=TRUE)

#off_day
offd1<-merged%>%filter((On=="연차"|Off_time=="연차")
  |(On=="경조"|On=="병가")|(Off_time=="경조"|Off_time=="병가")
  |(On=="재휴"|Off_time=="재휴"))%>%
  mutate(off_day=1)%>%select(key,off_day)

offd2<-merged%>%filter(missinatt==1 & is.na(holiday) &is.na(work))%>%
  mutate(off_day=1)%>%select(key,off_day)

offd<-rbind(offd1,offd2)
merged<-merge(merged,offd,by='key',all=TRUE)

#out_day
outd<-merged%>%
  filter((On=="교육"|On=="외근"|On=="워크샵"|On=="훈련"|On=="학교"|On=="출장")|
           (Off_time=="교육"|Off_time=="외근"|Off_time=="워크샵"
            |Off_time=="훈련"|Off_time=="학교"|Off_time=="출장"))%>%
  mutate(out_day=1)%>%select(key,out_day)
merged<-merge(merged,outd,by='key',all=TRUE)

#flowable_day
flowable1<-merged%>%filter(grepl("재",On))%>%
  mutate(flowable_day=1)%>%select(key,flowable_day)
flowable2<-merged%>%filter(grepl("재",Off_time))%>%
  mutate(flowable_day=1)%>%select(key,flowable_day)
flowable<-rbind(flowable1,flowable2)%>%
  group_by(key)%>%summarise(flowable_day=max(flowable_day))

merged<-merge(merged,flowable,by='key',all=TRUE)

##restday ##last기준
rest1<-merged%>%filter(No=="4020014")%>%
  filter(as.POSIXlt(date)$mon==6|as.POSIXlt(date)$mon==7)%>%
  mutate(rest_day=1)%>%select(key,rest_day)
rest2<-merged%>%filter(No=="4024024")%>%
  filter(as.POSIXlt(date)$mon==2)%>%
  mutate(rest_day=1)%>%select(key,rest_day)
rest3<-merged%>%filter(No=="4024062")%>%
  filter(as.POSIXct(date)>=as.POSIXct("2015-06-15")&as.POSIXct(date)<=as.POSIXct("2015-10-31"))%>%
  mutate(rest_day=1)%>%select(key,rest_day)

restd<-rbind(rest1,rest2,rest3)
merged<-merge(merged,restd,by='key',all=TRUE)

#etc_Day ##attend에 있는사람만 나옴, 없는사람들은 offday로 걸렀음!
etcd<-merged%>%
filter(is.na(work)&is.na(holiday)&is.na(half_am)
       &is.na(half_pm)&is.na(off_day)&is.na(out_day)&is.na(flowable_day)&is.na(rest_day))




########################################################################################
test<-last%>%mutate(ttmon=as.POSIXlt(date)$mon)%>%group_by(No,ttmon)%>%summarise(count=length(No))
test2<-test%>%group_by(No)%>%summarise(tt=length(ttmon))

minmax$min_date<-as.POSIXlt(minmax$min_date)
minmax$max_date<-as.POSIXlt(minmax$max_date)

minmax2<-minmax%>%mutate(minmon=min_date$mon, maxmon=max_date$mon)

###
merged[2,]$work_time.mins.
###test
test<-merged%>%filter((On=="교육"|On=="문행"|On=="외근"|On=="워크샵"|On=="출장"|On=="학교"|On=="훈련")|(
  Off_time=="교육"|Off_time=="문행"|Off_time=="외근"|Off_time=="워크샵"
  |Off_time=="출장"|Off_time=="학교"|Off_time=="훈련"))
test<-merged%>%filter(On=="경조"|On=="병가"|On=="연차")
test<-merged%>%filter(On=="재휴"|Off_time=="재휴")
View(merged)
