# 코드 정리

# 기본단계 
# 1. 사번별로 쪼개서 이용 
library(dplyr)
last<-read.csv('last.csv')
num <-list()
tmp <- unique(last$No)
length(tmp)
for(i in 1:length(tmp)){
  num[[i]]<-last%>%filter(No==tmp[i])
}
View(num[[1]])
for(i in 1:length(tmp)){
  test<-data.frame(num[[i]])
  name <-paste0("byNo",i,".csv")
  write.csv(test,name,row.names=FALSE)
}

# getwd()
byNo <- list()
for(i in 1:270){
  filename<-paste0("byNo/byNo",i,".csv",sep="")
  byNo[[i]]<-read.csv(filename)
}

View(byNo[[1]])
str(byNo[[1]])
dim(byNo[[1]])

#newdf[[사람]][[일자]]로 데이터 뽑기 좋은 형태로 만듬. 
newdf <-list()
i <- 1
j <- 1

for(i in 1:length(byNo)){
  datelist <- sort(unique(byNo[[i]]$date))
  tmp <- list()
  for(j in 1:length(datelist)){
    tmp[[j]] <- byNo[[i]][byNo[[i]]$date==datelist[j],]
  }
  newdf[[i]] <- tmp
}


## 지각 뽑기. 

late<-list()
i <- 1
j <- 1

for(i in 1:length(byNo)){
  tmp22<-unique(byNo[[i]]$date)
  tmp <- list()
  late[[i]] <- 0
  for(j in 1:length(tmp22)){
    dates <-paste(newdf[[i]][[j]]$date,newdf[[i]][[j]]$time)
    z<-as.POSIXlt(dates)
    if(dim(newdf[[i]][[j]] %>%
           mutate(time_c = z$hour)%>%
           filter(6<time_c & time_c< 10))[1] == 0){
        tmp[[j]] <-  newdf[[i]][[j]]%>%
        mutate(time_h = z$hour)%>%
        mutate(time_m = z$min)%>%
        select(time_h,time_m)%>%
        filter(time_h >= 10) 
      late[[i]] <- rbind(late[[i]],paste(newdf[[i]][[j]]$date[1],newdf[[i]][[j]]$No[1],tmp[[j]][1,1],tmp[[j]][1,2]))
    }
  }
}
#출퇴근 시간 뽑기
# 퇴근 시간 기준으로 야근도 뽑음.
library(dplyr)
i <- 1
j <- 1
str(byNo[[1]])
on<-list()
off<-list()
overoff<-list()
for(i in 1:(length(byNo))){
  tmp33<-unique(byNo[[i]]$date)
  moring<-list()
  offt<- list()
  on[[i]]<-0
  off[[i]]<-0
  overoff[[i]]<-0
  # offt6<-list()
  for(j in 1:(length(tmp33)-1)){
    dates <-paste(newdf[[i]][[j]]$date,newdf[[i]][[j]]$time)
    z<-as.POSIXlt(dates)
    #moring에는 출근 시간을 저장 (기준 : 06:00)
    moring[[j]]<- newdf[[i]][[j]] %>%
      mutate(time_h = z$hour)%>%
      mutate(time_m = z$min)%>%
      filter(dim(newdf[[i]][[j]])[1] !=0 & 6<time_h)
    if(dim(moring[[j]])[1] !=0){
      moring[[j]]<-mutate(moring[[j]],time_a = paste0(moring[[j]]$time_h,':',moring[[j]]$time_m))
      on[[i]]<-rbind(on[[i]],moring[[j]][1,])
    }
    #offt에는 퇴근 시간을 저장
    offt <- newdf[[i]][[j]] %>%
      mutate(time_h = z$hour)%>%
      mutate(time_m = z$min)%>%
      filter(dim(newdf[[i]][[j]])[1] !=0 & 6<time_h &time_h<=23) 
    #(time_h<= 6 | time_h>=18))
    #변수만들기
    if(dim(offt)[1] != 0){
      offt<-mutate(offt,time_a = paste0(offt$time_h,':',offt$time_m))
      off[[i]]<-rbind(off[[i]],offt[nrow(offt),])
    }
    #offt6 만들기(퇴근시간<=6)
    dates2 <-paste(newdf[[i]][[j+1]]$date,newdf[[i]][[j+1]]$time)
    z2<-as.POSIXlt(dates2)
    offt6 <- newdf[[i]][[j+1]] %>%
      mutate(time_h = z2$hour)%>%
      mutate(time_m = z2$min)%>%
      filter(dim(newdf[[i]][[j+1]])[1] !=0 & time_h<=6) 
    if(dim(offt6)[1] != 0){
      offt6<-mutate(offt6, time_a=paste0(offt6$time_h,':',offt6$time_m))
      overoff[[i]] <-rbind(overoff[[i]],offt6[nrow(offt6),])
    }
    #on[[i]]<-rbind(on[[i]],moring[[j]][1,])
    #off[[i]]<-rbind(off[[i]],offt[[j]][nrow(offt[j]),])
    #overoff[[i]]<-rbind(overoff[[i]],offt6[[j]][nrow(offt[j]),])
  }
}
i
j
View(on[[1]])
View(off[[1]])
View(overoff[[1]])



#각각 off[[1]] , overoff[[1]] 중 겹치는게 있으면
# overoff[[1]] 로 통일하자!

temp<-off[[1]]$date%in%overoff[[1]]$date
test<-cbind(off[[1]],temp)
View(test)
# true이면 overoff[[1]]로 변경
i<-1
j<-1
for(i in 2:dim(test)[1]){
  if(test$temp[i]==TRUE){
    for(j in 2:dim(overoff[[1]])[1]){
      if(test$date[i]== overoff[[1]]$date[j]){
        test$time[i]= overoff[[1]]$time
        test$time_h[i]= overoff[[1]]$time_h[j]
        test$time_m[i]= overoff[[1]]$time_a[j]
        test$time_a[i]= overoff[[1]]$time_a[j]
      }
    }
  }
}
#이걸 전체를 돌린다면!
i<-1
j<-1
k<-1
test<-list()
for(k in 1:length(off)){
  temp<-as.data.frame(off[[k]])$date%in%as.data.frame(overoff[[k]])$date
  test[[k]]<-as.data.frame(cbind(off[[k]],temp))
  for(i in 2:dim(test[[k]])[1]){
    if(test[[k]]$temp[i]==TRUE){
      for(j in 2:dim(overoff[[k]])[1]){
        if(test[[k]]$date[i-1]== overoff[[k]]$date[j]){
          test[[k]]$time[i-1]= overoff[[k]]$time
          test[[k]]$time_h[i-1]= overoff[[k]]$time_h[j]
          test[[k]]$time_m[i-1]= overoff[[k]]$time_a[j]
          test[[k]]$time_a[i-1]= overoff[[k]]$time_a[j]
        }
      }
    }
  }
}
View(test[[250]])
length(off)
View(test)

#
ftmp <- on[[1]]
i<-1
for(i in 2:length(on)){
  ftmp <- rbind(ftmp,as.data.frame(on[[i]]))
}
View(ftmp)
getwd()
write.csv(ftmp,'lastgeton.csv',row.names = FALSE)

ftmp2 <- data.frame()
ftmp2 <- test[[1]]
i<-1
for(i in 2:length(test)){
  ftmp2 <- rbind(ftmp2,as.data.frame(test[[i]]))
}
View(ftmp2)
write.csv(ftmp2,'lastgetoff.csv',row.names = FALSE)


# 근무시간 뽑기 
# 출근 시간 - 퇴근 시간

library(dplyr)

work_time <-list()
i <- 1
j <- 1
wt <- 0
str(byNo[[1]])
for(i in 1:(length(byNo))){
  tmp33<-unique(byNo[[i]]$date)
  tmp<-list()
  tmp2<- list()
  work_time[[i]] <- 0
  for(j in 1:(length(tmp33)-1)){
    dates <-paste(newdf[[i]][[j]]$date,newdf[[i]][[j]]$time)
    z<-as.POSIXlt(dates)
    #moring에는 출근 시간을 저장 (기준 : 06:00)
    tmp[[j]]<- newdf[[i]][[j]] %>%
      mutate(time_h = z$hour)%>%
      mutate(time_m = z$min)%>%
      filter(dim(newdf[[i]][[j]])[1] !=0 & 6<time_h)
    if(dim(tmp[[j]])[1] !=0){
      tmp[[j]]<-mutate(tmp[[j]],time_a = paste0(tmp[[j]]$time_h,':',tmp[[j]]$time_m))
    }
    #moring
    #moring <-tmp[[i]]%>%
    #                filter(6<time_j[1]<12)
    #moring2
    #moring2<- tmp[[j]]%>%
    #                filter(time_h[1]>=12)
    #tmp2에는 퇴근 시간을 저장
    tmp2[[j]] <- newdf[[i]][[j]] %>%
      mutate(time_h = z$hour)%>%
      mutate(time_m = z$min)%>%
      filter(dim(newdf[[i]][[j]])[1] !=0 & time_h<=23) 
    #(time_h<= 6 | time_h>=18))
    # 6 , 18  이 문제네 ! 
    #변수만들기
    if(dim(tmp2[[j]])[1] != 0){
      tmp2[[j]]<-mutate(tmp2[[j]],time_a = paste0(tmp2[[j]]$time_h,':',tmp2[[j]]$time_m))
    }
    #tmp3 만들기(퇴근시간<=6)
    dates2 <-paste(newdf[[i]][[j+1]]$date,newdf[[i]][[j+1]]$time)
    z2<-as.POSIXlt(dates2)
    tmp3 <- newdf[[i]][[j+1]] %>%
      mutate(time_h = z2$hour)%>%
      mutate(time_m = z2$min)%>%
      filter(dim(newdf[[i]][[j+1]])[1] !=0 & time_h<=6) 
    if(dim(tmp3)[1] != 0){
      tmp3<-mutate(tmp3, time_a = paste0(tmp3$time_h,':',tmp3$time_m)) 
    }
    # j가 의미하는 것은 날짜를 의미함!
    # 일한 시간!
    if((dim(tmp3)[1] != 0 | dim(tmp2[[j]])[1] != 0) & dim(tmp[[j]])[1] != 0 & j>1){
      # tmp2[[j]] - tmp[[j]] -> (if : tmp2[[j]]의 time_h>18 일 경우)
      #  if(tmp2[[j]][nrow(tmp2[[j]]),'time_h'] >=18 ){
      #      t1 <- as.difftime(tmp2[[j]][nrow(tmp2[[j]]),'time_a'],format = '%H:%M')
      #     t2 <- as.difftime(tmp[[j]][1,'time_a'],format = '%H:%M')
      #    wt <- as.numeric((t1-t2),units='mins')
      #  work_time[[i]] <- rbind(work_time[[i]],paste(newdf[[i]][[j]]$date[1],newdf[[i]][[j]]$No[1],wt))
      # }      
      # tmp2[[j]] - tmp[[j-1]] -> (tmp2[[j]]의 time_h <6일 경우)
      # j-1일 경우 j-1 안왓을 경우도 있음.
      # 이경우는 시간을 환산을 해야함.
      # 야근임! 
      if(dim(tmp3)[1] != 0 &dim(tmp[[j-1]])[1]!= 0)
      {
        # 이 경우가 그 전날 시간과 빼야됨 ! 기준은 그 전날 j에 저장!
        t1 <- as.difftime(tmp3$time_a,format='%H:%M')
        t2 <- as.difftime(tmp[[j-1]][1,'time_a'],format='%H:%M')
        add <- as.difftime('24:00',format='%H:%M')
        wt <-  as.numeric((t1-t2+add),units='mins')
        work_time[[i]] <- rbind(work_time[[i]],paste(newdf[[i]][[j]]$date[1],newdf[[i]][[j]]$No[1],wt))
      }
      else if(dim(tmp2[[j]])[1] != 0 &dim(tmp[[j]])[1]!= 0){
        t1<- as.difftime(tmp2[[j]][nrow(tmp2[[j]]),'time_a'],format='%H:%M')
        t2<- as.difftime(tmp[[j]][1,'time_a'],format = '%H:%M')
        wt <- as.numeric((t1-t2),units='mins')
        work_time[[i]] <- rbind(work_time[[i]],paste(newdf[[i]][[j]]$date[1],newdf[[i]][[j]]$No[1],wt))
      }
    }
    # }else if(tail(z$hour) <=17 &dim(tmp[[j]])[1] != 0 &dim(newdf[[i]][[j]])[1] != 0){
    #   #   if(){
    #   #      
    #   #     
    #   #   }
    #   # 17시 이전에 퇴근한 사람들 일한 시간 넣어주자! holiday든 모든지!
    #   # tmp3[[j]]가 존재하고 
    #   t1<- as.difftime(paste0(tail(z$hour),':',tail(z$min)),format = '%H:%M')
    #   t2<- as.difftime(tmp[[j]][1,'time_a'],format = '%H:%M')
    #   wt <- as.numeric((t1-t2),units='mins')
    #   work_time[[i]] <- rbind(work_time[[i]],paste(newdf[[i]][[j]]$date[1],newdf[[i]][[j]]$No[1],wt))
    # }
  }
}
# 맨앞 맨끝은 근데 사실상 불가능 함! 평균 시간 구할 때 빼서구하자 

#반차 
#연차
#휴게실은 total2.R


## test
class(z$hour)
tail(z$hour)[4]
i
j
View(newdf[[1]][[131]])
tmp[[j-1]]
View(newdf[[270]])
View(tmp[[7]])
View(tmp2[[7]])
View(work_time[[2]])

tmp3<- tmp2[[7]] %>%
  filter(time_h <6)%>%
  select(time_a)


t1 <- as.difftime('10:49',format = '%H:%M')
t2 <- as.difftime('01:51',format = '%H:%M')
add <-as.difftime('24:00',format = '%H:%M')
a <- t1 - t2
a <- as.numeric((t2 - t1),units='mins')
a2<-as.numeric((t2 - t1+add), units='mins')
12*60

## write 용 바탕
ftmp <- data.frame()
ftmp <- work_time[[1]][,1]
View(fwork)
i<-1
for(i in 2:length(work_time)){
  ftmp <- rbind(ftmp,as.data.frame(work_time[[i]][,1]))
}

View(ftmp)
colsnames(ftmp)
getwd()
write.csv(ftmp,"ftest.csv",row.names = FALSE)
View(ftmp)
2098
2098-1689
View(as.data.frame(work_time[[86]][,1]))
work_time[[86]][,1]
class(work_time[[86]])
test <- read.csv('ftest.csv')
View(test)





