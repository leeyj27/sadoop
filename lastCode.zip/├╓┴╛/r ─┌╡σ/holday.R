#hoilday 나누자

library('dplyr')

getwd()
target<-read.csv('target2.csv')

tmp<-unique(target$No)
length(tmp)
i<-1
num <-list()
holsum<-list()
week<-list()

length(tmp)
for(i in 1:length(tmp)){
  num[[i]]<-target%>%filter(No==tmp[i])
  holsum[[i]]<-sum(num[[i]]$holiday)
  week[[i]]<-dim(num[[i]]%>%filter(holiday==0))[1]
}
View(num[[1]])
holsum2<-data.frame()
holsum2<-holsum[[1]]
weekday<-week[[1]]
i<-1
for(i in 2:length(holsum)){
  holsum2 <- rbind(holsum2,as.data.frame(holsum[[i]]))
  weekday <-rbind(weekday,as.data.frame(week[[i]]))
}

View(holsum2)
View(weekday)
write.csv(holsum2,'temp.txt',row.names = FALSE)
write.csv(weekday,'weekday.txt',row.names =FALSE)
week[[2]]
